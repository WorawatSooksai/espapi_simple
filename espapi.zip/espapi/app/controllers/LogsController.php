<?php

namespace App\Controllers;

use App\Models\Log;
use App\Models\Variable;

class LogsController extends Controller
{    
    /**
     * Display a listing of the resource.
     */
    public function index() {
        response()->json(Log::all());
    }
    public function insLog($v_name,$val){
        $var = Variable::where("name",$v_name)->first();
        response()->json($var);
        $res = Log::insert([
            "v_".$var['type'] => $val,
            "variable_id" => $var['id'],
            "created_at" => date("Y-m-d H:i:s")
        ]);

        response()->json(["logInserted"=>$res]);


    }
    public function loglast($v_name){

        $vallast = Log::join('variables','variables.id','logs.variable_id')
        ->where('variables.name',$v_name) 
        ->orderBy('logs.created_at','desc')
        ->select('logs.*','variables.name','variables.type')
        ->first();

        response()->json($vallast);  
        // INNER JOIN variables ON variables.id = logs.variable_id 

    }
    public function store()
    {
        /*
        |--------------------------------------------------------------------------
        |
        | This is an example which deletes a particular row. 
        | You can un-comment it to use this example
        |
        */
        // $row = new Log;
        // $row->column = request()->get('column');
        // $row->delete();
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update($id)
    {
        /*
        |--------------------------------------------------------------------------
        |
        | This is an example which edits a particular row. 
        | You can un-comment it to use this example
        |
        */
        // $row = Log::find($id);
        // $row->column = request()->get('column');
        // $row->save();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        /*
        |--------------------------------------------------------------------------
        |
        | This is an example which deletes a particular row. 
        | You can un-comment it to use this example
        |
        */
        // $row = Log::find($id);
        // $row->delete();
    }
}
