<?php

app()->get('/', function () {
    response()->json(['message' => '662021xxx have api']);
});

app()->get('/var','VariablesController@index');
app()->get('/insertGet/{v_name}/{v_type}'
,'VariablesController@insertGet');

app()->get('/log/{v_name}/{value}','LogsController@insLog');
app()->get('/log','LogsController@index');
app()->get('/loglast/{v_name}','LogsController@loglast');
