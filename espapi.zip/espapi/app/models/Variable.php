<?php

namespace App\Models;

class Variable extends Model
{
    // 
}
