<?php

namespace App\Models;

class Log extends Model
{
    // 
}
